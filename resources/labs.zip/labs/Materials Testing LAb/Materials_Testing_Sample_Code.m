%Materials Testing Script File - Updated 10/18/19 

clear; clc; close all;

%This script file was created as an example for the Materials Testing Lab
%The students can use this script file as a starting point.  
%They should cite the source of this code and comment
%the code to document their changes.


%load the data
%the format assumed is two columns. The first column is the force data and
%the second column is the associated deflection values in inches
%using xlsread to load this data
force = xlsread('Materials_Testing_Datasheet.xlsx','Beam_Bending','J17:J22');
steel_def = xlsread('Materials_Testing_Datasheet.xlsx','Beam_Bending','K17:K22');
brass_def = xlsread('Materials_Testing_Datasheet.xlsx','Beam_Bending','L17:L22');
alum_def = xlsread('Materials_Testing_Datasheet.xlsx','Beam_Bending','M17:M22');
alum_box_def = xlsread('Materials_Testing_Datasheet.xlsx','Beam_Bending','N17:N22');


%plotting the data
figure (1)
hold on
plot (force, steel_def, 'r+');
plot (force, brass_def, 'g+');
plot (force(1:5), alum_def, 'b+');
plot (force, alum_box_def, 'k+');

%determine the linear trendline for the data

%the polyfit function returns a vector of the coefficients from the
%trendline and takes the following format 
% C = polyfit(x,y,N) 
%where N is the power of the trendline and the values
%in C are the coefficients.  For a linear trendline the value 
%of N would be 1, for a quadtratic fit, N would be 2, etc.
%coeffecients of the linear trendlines will need to be found for each
%material ploted

C_steel=polyfit(force, steel_def, 1);
C_brass=polyfit(force, brass_def, 1);
C_alum=polyfit(force(1:5), alum_def, 1);
C_alum_box=polyfit(force, alum_box_def, 1);

%Now we need to plot the linear trendline using the coefficients produced
%by the polyfit function.  To do so, we need to create a variable to use
%for x using linspace to create 20 points equally spaced between 0 and
%your maximum force value
x=linspace(0, max(force), 20);

%create a linear line using y=C*x 
%where C is coeffecient returned from the polyfit function above
lin_steel=C_steel(1)*x;
lin_brass=C_brass(1)*x;
lin_alum=C_alum(1)*x;
lin_alum_box=C_alum_box(1)*x;


%plot the linear trendline on the same graph as your raw data
plot(x,lin_steel,'r')
plot(x,lin_brass,'g')
plot(x,lin_alum,'b')
plot(x,lin_alum_box,'k')

xlabel('Force Applied (N)');
ylabel('Deflection Measured (m)');
title('Force and Deflection plot for Materials Testing Lab');


%then, to label the trendline with the proper equation, using the gtext
%command allows you to click where you want to place the text once the
%figure opens

steel_str=sprintf('Steel = %fx', C_steel(1));
brass_str=sprintf('Brass = %fx', C_brass(1));
alum_str=sprintf('Aluminum = %fx', C_alum(1));
alum_box_str=sprintf('Hollow Aluminum = %fx', C_alum_box(1));
gtext(steel_str)
gtext(brass_str)
gtext(alum_str)
gtext(alum_box_str)

legend('Steel','Brass','Aluminum','Aluminum (hollow)','Steel','Brass','Aluminum','Hollow Aluminum');



hold off



