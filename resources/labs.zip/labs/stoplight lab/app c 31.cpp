#include<FEHUtility.h>
#include<FEHLCD.h>
DigitalOutputPin green1(FEHIO::P0_0);
DigitalOutputPin yellow1(FEHIO::P0_1);
DigitalOutputPin red1(FEHIO::P0_2);
DigitalOutputPin walk1(FEHIO::P0_4);
DigitalOutputPin dontWalk1(FEHIO::P0_3);

DigitalOutputPin green2(FEHIO::P1_0);
DigitalOutputPin yellow2(FEHIO::P1_1);
DigitalOutputPin red2(FEHIO::P1_2);
DigitalOutputPin walk2(FEHIO::P1_4);
DigitalOutputPin dontWalk2(FEHIO::P1_3);


int main()
{
//Declaring and defining some variables

int isNSgreen = 0;
int isEWgreen = 0;
float totalTime = 0;
float timeProg = 0;
int end = 0;

//Printing and getting some values	
LCD.Write("\n\nThe lights will now be simulated.\n\n");

while (end != 1)
{

	LCD.WriteLine("NS light = green, EW light = red\nWaiting 7 seconds...");
	DigitalOutputPin InputName3(FEHIO::P2_3);
Sleep(7.0);
	LCD.WriteLine("NS light = yellow, EW light = red\nWaiting 2 seconds...");
Sleep(2.0);
	LCD.Writeline("NS light = red, EW light = green\nWaiting 7 seconds...");
Sleep(7.0);
	LCD.Writeline("NS light = red, EW light = yellow\nWaiting 2 seconds...");
Sleep(2.0);

}
	
	
}
